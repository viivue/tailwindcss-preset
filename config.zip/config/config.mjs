// You don't need to modify this file unless deeper custom is required

export const configPropertyName = {
    // use for custom variable
    // --vii-spacing-16
    // --vii-size-16

    // format: {tailwindKey :custom property name}

    fontFamily: 'font',
    colors: 'color',
    spacing: 'spacing',
    fontSize: 'size',
}